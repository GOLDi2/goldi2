#ifndef AUTOMAT_H_
#define AUTOMAT_H_

#include "3Axis.h"

typedef enum
{
	Init,
	DriveUp,
	DriveDown,
	DriveRight,
	DriveLeft
}AutomatStates_t;

extern void StateMachineInit(void);		// This function init the state machine.
extern void StateMachineUpdate(void);	// This function updated the state machine.


#endif /* AUTOMAT_H_ */