#include <avr/io.h>
#include <util/delay.h>

#include "UART0.h"
#include "Automaton/Automaton.h"
#include "BusProtectionInterface.h"

int main(void)
{
	UART0_init();
	BusProtectionInterfaceInit();
	
	StateMachineInit();
	
	while(1)
    {
		StateMachineUpdate();
		BusProtectionSendData();
    }
}