/*
 * DriveControl.c
 *
 * Created: 24.04.2015 09:00:53
 *  Author: Alexander
 */ 
#include <util/delay.h>
#include "UserDesign.h"


int error = 0;
int dx = 0;
int dy = 0;

int CurrentPositionX = 0;
int CurrentPositionY = 0;

int ReachedPosition = 0;

void DriveToPositionX(int x)
{
	while(Sensors.PositionX != x)
	{
		if(Sensors.PositionX < x)
		{
			Actuators.XAxisDriveToXPlus	 = 1;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
			while(Sensors.PositionX < x)
				GOLDiInterfaceSendData();
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
		}
		else
		{
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 1;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
			while(Sensors.PositionX > x)
				GOLDiInterfaceSendData();
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
		}
	}
	//else
	//{
		Actuators.XAxisDriveToXPlus	 = 0;
		Actuators.XAxisDriveToXMinus = 0;
		Actuators.YAxisDriveToYPlus	 = 0;
		Actuators.YAxisDriveToYMinus = 0;
		Actuators.ZAxisDriveToZPlus	 = 0;
		Actuators.ZAxisDriveToZMinus = 0;
		GOLDiInterfaceSendData();
	//}
}

void DriveToPositionY(int y)
{
	while(Sensors.PositionY != y)
	{
		if(Sensors.PositionY < y)
		{
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 1;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
			while(Sensors.PositionY < y)
				GOLDiInterfaceSendData();
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
			//_delay_ms(2000);
		}
		else
		{
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 1;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
			while(Sensors.PositionY > y)
				GOLDiInterfaceSendData();
			Actuators.XAxisDriveToXPlus	 = 0;
			Actuators.XAxisDriveToXMinus = 0;
			Actuators.YAxisDriveToYPlus	 = 0;
			Actuators.YAxisDriveToYMinus = 0;
			Actuators.ZAxisDriveToZPlus	 = 0;
			Actuators.ZAxisDriveToZMinus = 0;
			GOLDiInterfaceSendData();
		}
	}
	//else
	//{
		Actuators.XAxisDriveToXPlus	 = 0;
		Actuators.XAxisDriveToXMinus = 0;
		Actuators.YAxisDriveToYPlus	 = 0;
		Actuators.YAxisDriveToYMinus = 0;
		Actuators.ZAxisDriveToZPlus	 = 0;
		Actuators.ZAxisDriveToZMinus = 0;
		GOLDiInterfaceSendData();
	//}
}

void DriveLine(int x, int y)
{
	while(CurrentPositionX < x)
	{
		CurrentPositionX += 1;
		error = error - dy;
		if(error < 0)
		{
			CurrentPositionY += 1;
			error = error + dx;
		}
		DriveToPosition(CurrentPositionX, CurrentPositionY);
	}
}

void DriveToPosition(int x, int y)
{
	
	DriveToPositionX(x);
	DriveToPositionY(y);
}

void InitializeLine(int x, int y)
{
	dx = x - Sensors.PositionX;
	dy = y - Sensors.PositionY;
	CurrentPositionY = 0;
	CurrentPositionX = 0;
	error = dx/2;
}

void rasterCircle(int xmittel, int ymittel, int radius)
{
	int error = radius;
	int x = radius;
	int y = 0;
	int dx = 0;
	int dy = 0;
	volatile int ValuesX[100];
	volatile int ValuesY[100];
	volatile int ValuePointer = 0;
	
	DriveToPosition(xmittel + x, ymittel + y);
	
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}

		DriveToPosition(xmittel + x, ymittel + y);
	}

	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}
		
		ValuesX[ValuePointer] = xmittel + y;
		ValuesY[ValuePointer] = ymittel + x;
		ValuePointer++;
	}
	
	for (int i = ValuePointer ; i > 0; i-- )
	{
		DriveToPosition(ValuesX[i-1], ValuesY[i-1]);
	}

	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}

		DriveToPosition(xmittel - y, ymittel + x);
	}
	
	ValuePointer = 0;
	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}


		ValuesX[ValuePointer] = xmittel - x;
		ValuesY[ValuePointer] = ymittel + y;
		ValuePointer++;
	}
	
	for (int i = ValuePointer ; i > 0; i-- )
	{
		DriveToPosition(ValuesX[i-1], ValuesY[i-1]);
	}

	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}

		DriveToPosition(xmittel - x, ymittel - y);
	}
	
	ValuePointer = 0;
	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}


		ValuesX[ValuePointer] = xmittel - y;
		ValuesY[ValuePointer] = ymittel - x;
		ValuePointer++;
	}
	
	for (int i = ValuePointer ; i > 0; i-- )
	{
		DriveToPosition(ValuesX[i-1], ValuesY[i-1]);
	}

	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}

		DriveToPosition(xmittel + y, ymittel - x);
	}

	ValuePointer = 0;
	error = radius;
	x = radius;
	y = 0;
	while (y < x)
	{
		dy = y * 2 + 1;
		y += 1;
		error = error - dy;
		if (error < 0)
		{
			dx = 1 - x * 2;
			x = x - 1;
			error = error - dx;
		}


		ValuesX[ValuePointer] = xmittel + x;
		ValuesY[ValuePointer] = ymittel - y;
		ValuePointer++;
	}
	
	for (int i = ValuePointer ; i > 0; i-- )
	{
		DriveToPosition(ValuesX[i-1], ValuesY[i-1]);
	}
}

