// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include "GOLDiInterface/GOLDiInterface.h"
#include "UserDesign/UserDesign.h"

int main(void)
{
    GOLDiInterfaceInit();                                                                       // Initialize the bus interface
    
	Actuators.XAxisDriveToXPlus	 = 1;
	Actuators.XAxisDriveToXMinus = 0;
	Actuators.YAxisDriveToYPlus	 = 0;
	Actuators.YAxisDriveToYMinus = 0;
	Actuators.ZAxisDriveToZPlus	 = 0;
	Actuators.ZAxisDriveToZMinus = 0;
	GOLDiInterfaceSendData();
	
    while(1)
    {
		DriveToPosition(0,0);
        InitializeLine(150, 40);
        DriveLine(150,40);
        rasterCircle(100,25,25);
    }
}