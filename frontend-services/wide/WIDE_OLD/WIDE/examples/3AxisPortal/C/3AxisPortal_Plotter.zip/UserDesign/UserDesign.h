/*
 * DriveControl.h
 *
 * Created: 24.04.2015 09:01:11
 *  Author: Alexander
 */ 


#ifndef USERDESIGN_H_
#define USERDESIGN_H_

#include "../GOLDiInterface/GOLDiInterface.h"
#include "../Main.h"

void DriveToPositionX(int x);
void DriveToPositionY(int y);
void DriveLine(int x, int y);
void DriveToPosition(int x, int y);
void InitializeLine(int x, int y);
void rasterCircle(int x0, int y0, int radius);

#endif /* DRIVECONTROL_H_ */