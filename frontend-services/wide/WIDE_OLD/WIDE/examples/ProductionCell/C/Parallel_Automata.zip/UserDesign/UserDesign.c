// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include <util/delay.h>
#include "UserDesign.h"

AutomatTransportTable_t A0_State;			//Machine handling the transport table
AutomatTransportTable_t A0_NextState;

AutomatTurnTable1_t		A1_State;			//Machine handling the turntable 1
AutomatTurnTable1_t		A1_NextState;

AutomatMillingMachine_t	A2_State;			//Machine handling the milling machine
AutomatMillingMachine_t	A2_NextState;

AutomatTurnTable2_t		A3_State;			//Machine handling the turntable 2
AutomatTurnTable2_t		A3_NextState;


// ######################################################################################
// #  This function initializes the finite state machine with start state               #
// ######################################################################################
void StateMachineInit(void)
{
	A0_State = AutomatTransportTable_Start;
	A0_NextState = AutomatTransportTable_Start;

	A1_State = AutomatTurnTable1_Start;
	A1_NextState = AutomatTurnTable1_Start;
	
	A2_State = AutomatMillingMachine_Start;
	A2_NextState = AutomatMillingMachine_Start;

	A3_State = AutomatTurnTable2_Start;
	A3_NextState = AutomatTurnTable2_Start;

}

// ######################################################################################
// #  This function updates the current state of the finite state machine               #
// ######################################################################################
void StateMachineUpdate(void)
{
	//Transition function delta for A0 (transport table)
	switch (A0_State)
	{
		case AutomatTransportTable_Start:							// Z0
		{
			if(!Sensors.TransportTableInLineWithConveyorBelt3)		// S(Z0,!x0) = Z1
			{
				A0_NextState = AutomatTransportTable_DriveRight;
			}
			else													// S(Z0,x0) = Z2
			{
				A0_NextState = AutomatTransportTable_ArriveRight;
			}
			break;
		}

		case AutomatTransportTable_DriveRight:						// Z1
		{
			if(Sensors.TransportTableInLineWithConveyorBelt3)		// S(Z1,x0) = Z2
			{
				A0_NextState = AutomatTransportTable_ArriveRight;
			}
			else													// S(Z1,!x0) = Z1
			{
				A0_NextState = AutomatTransportTable_DriveRight;
			}
			break;
		}

		case AutomatTransportTable_ArriveRight:						// Z2
		{
			if(Sensors.ConveyorBelt3WorkpieceAvailable)				// S(Z1,x11) = Z3
			{
				A0_NextState = AutomatTransportTable_PullBrick;
			}
			else													// S(Z2,!x11) = Z2
			{
				A0_NextState = AutomatTransportTable_ArriveRight;
			}
			break;
		}

		case AutomatTransportTable_PullBrick:						// Z3
		{
			if(Sensors.TransportTableWorkpieceAvailable)			// S(Z1,x2) = Z4
			{
				A0_NextState = AutomatTransportTable_DriveLeft;
			}
			else													// S(Z3,!x2) = Z3
			{
				A0_NextState = AutomatTransportTable_PullBrick;
			}
			break;
		}

		case AutomatTransportTable_DriveLeft:						// Z4
		{
			if(Sensors.TransportTableInLineWithWonveyorBelt1)		// S(Z1,x1) = Z5
			{
				A0_NextState = AutomatTransportTable_WaitForFree;
			}
			else													// S(Z4,!x1) = Z4
			{
				A0_NextState = AutomatTransportTable_DriveLeft;
			}
			break;
		}

		case AutomatTransportTable_WaitForFree:						// Z5
		{
			if(!Sensors.ConveyorBelt1WorkpieceAvailable)			// S(Z1,!x3) = Z6
			{
				A0_NextState = AutomatTransportTable_MoveBrick;
			}
			else													// S(Z5,x3) = Z5
			{
				A0_NextState = AutomatTransportTable_WaitForFree;
			}
			break;
		}

		case AutomatTransportTable_MoveBrick:						// Z6
		{
			if(Sensors.ConveyorBelt1WorkpieceAvailable)				// S(Z6,x3) = Z0
			{
				A0_NextState = AutomatTransportTable_Start;
			}
			else													// S(Z6,!x3) = Z6
			{
				A0_NextState = AutomatTransportTable_MoveBrick;
			}
			break;
		}
	}


	//Transition function delta for A1 (turntable 1)
	switch (A1_State)
	{
		case AutomatTurnTable1_Start:								// Z0
		{
			if(!Sensors.Turntable1InLineWithConveyorBelt1)			// S(Z0,!x4) = Z1
			{
				A1_NextState = AutomatTurnTable1_DriveRight;
			}
			else													// S(Z0,x4) = Z2
			{
				A1_NextState = AutomatTurnTable1_ArriveRight;
			}
			break;
		}

		case AutomatTurnTable1_DriveRight:							// Z1
		{
			if(Sensors.Turntable1InLineWithConveyorBelt1)			// S(Z1,x4) = Z2
			{
				A1_NextState = AutomatTurnTable1_ArriveRight;
			}
			else													// S(Z1,!x4) = Z1
			{
				A1_NextState = AutomatTurnTable1_DriveRight;
			}
			break;
		}

		case AutomatTurnTable1_ArriveRight:							// Z2
		{
			if(Sensors.ConveyorBelt1WorkpieceAvailable)				// S(Z2,x3) = Z3
			{
				A1_NextState = AutomatTurnTable1_PullBrick;
			}
			else													// S(Z2,!x3) = Z2
			{
				A1_NextState = AutomatTurnTable1_ArriveRight;
			}
			break;
		}

		case AutomatTurnTable1_PullBrick:						// Z3
		{
			if(Sensors.Turntable1WorkpieceAvailable)				// S(Z3,x6) = Z4
			{
				A1_NextState = AutomatTurnTable1_DriveLeft;
			}
			else													// S(Z3,!x6) = Z3
			{
				A1_NextState = AutomatTurnTable1_PullBrick;
			}
			break;
		}

		case AutomatTurnTable1_DriveLeft:						// Z4
		{
			if(Sensors.Turntable1InLineWithConveyorBelt2)			// S(Z4,x5) = Z5
			{
				A1_NextState = AutomatTurnTable1_WaitForFree;
			}
			else													// S(Z4,!x5) = Z4
			{
				A1_NextState = AutomatTurnTable1_DriveLeft;
			}
			break;
		}

		case AutomatTurnTable1_WaitForFree:							// Z5
		{
			if(!Sensors.ConveyorBelt2WorkpieceAvailable)			// S(Z5,!x7) = Z6
			{
				A1_NextState = AutomatTurnTable1_MoveBrick;
			}
			else													// S(Z5,x7) = Z5
			{
				A1_NextState = AutomatTurnTable1_WaitForFree;
			}
			break;
		}

		case AutomatTurnTable1_MoveBrick:							// Z6
		{
			if(Sensors.ConveyorBelt2WorkpieceAvailable)				// S(Z6,x7) = Z0
			{
				A1_NextState = AutomatTurnTable1_Start;
			}
			else													// S(Z6,!x7) = Z6
			{
				A1_NextState = AutomatTurnTable1_MoveBrick;
			}
			break;
		}
	}

	//Transition function delta for A2 (milling machine)
	switch (A2_State)
	{
		case AutomatMillingMachine_Start:							// Z0
		{
			if(Sensors.ConveyorBelt2WorkpieceAvailable
			&& !Sensors.MillingHeadIsUp)							// S(Z0,x7&!x14) = Z1
			{
				A2_NextState = AutomatMillingMachine_RiseMill;
			}
			else if(Sensors.ConveyorBelt2WorkpieceAvailable
			&& Sensors.MillingHeadIsUp
			&& !Sensors.MillingMachineAtConveyorBelt2)				// S(Z0,x7&x14&!x13) = Z2
			{
				A2_NextState = AutomatMillingMachine_DriveToFront;
			}
			else if(Sensors.ConveyorBelt2WorkpieceAvailable
			&& Sensors.MillingHeadIsUp
			&& Sensors.MillingMachineAtConveyorBelt2)				// S(Z0,x7&x14&x13) = Z3
			{
				A2_NextState = AutomatMillingMachine_LowerAndDrill;
			}
			else													// S(Z0,!x7) = Z0
			{
				A2_NextState = AutomatMillingMachine_Start;
			}
			break;
		}

		case AutomatMillingMachine_RiseMill:						// Z1
		{
			if(Sensors.MillingHeadIsUp
			&& !Sensors.MillingMachineAtConveyorBelt2)				// S(Z1,x14&!x13) = Z2
			{
				A2_NextState = AutomatMillingMachine_DriveToFront;
			}
			else if(Sensors.MillingHeadIsUp
			&& Sensors.MillingMachineAtConveyorBelt2)				// S(Z1,x14&x13) = Z3
			{
				A2_NextState = AutomatMillingMachine_LowerAndDrill;
			}
			else													// S(Z1,!x14) = Z1
			{
				A2_NextState = AutomatMillingMachine_RiseMill;
			}
			break;
		}

		case AutomatMillingMachine_DriveToFront:					// Z2
		{
			if(Sensors.MillingMachineAtConveyorBelt2)				// S(Z2,x13) = Z3
			{
				A2_NextState = AutomatMillingMachine_LowerAndDrill;
			}
			else													// S(Z2,!x13) = Z2
			{
				A2_NextState = AutomatMillingMachine_DriveToFront;
			}
			break;
		}

		case AutomatMillingMachine_LowerAndDrill:					// Z3
		{
			if(Sensors.MillingHeadIsDown)							// S(Z3,x15) = Z4
			{
				A2_NextState = AutomatMillingMachine_RiseAndDrill;
			}
			else													// S(Z3,!x15) = Z3
			{
				A2_NextState = AutomatMillingMachine_LowerAndDrill;
			}
			break;
		}

		case AutomatMillingMachine_RiseAndDrill:					// Z4
		{
			if(Sensors.MillingHeadIsUp)								// S(Z4,x14) = Z5
			{
				A2_NextState = AutomatMillingMachine_DriveToBack;
			}
			else													// S(Z4,!x14) = Z4
			{
				A2_NextState = AutomatMillingMachine_RiseAndDrill;
			}
			break;
		}

		case AutomatMillingMachine_DriveToBack:						// Z5
		{
			if(Sensors.MillingMachineAwayFromConveyorBelt2)			// S(Z5,x12) = Z6
			{
				A2_NextState = AutomatMillingMachine_WaitBrickGo;
			}
			else													// S(Z5,!x12) = Z5
			{
				A2_NextState = AutomatMillingMachine_DriveToBack;
			}
			break;
		}

		case AutomatMillingMachine_WaitBrickGo:						// Z6
		{
			if(!Sensors.ConveyorBelt2WorkpieceAvailable)			// S(Z6,!x7) = Z0
			{
				A2_NextState = AutomatMillingMachine_Start;
			}
			else													// S(Z6,x7) = Z6
			{
				A2_NextState = AutomatMillingMachine_WaitBrickGo;
			}
			break;
		}
	}

	//Transition function delta for A3 (turntable 2)
	switch (A3_State)
	{
		case AutomatTurnTable2_Start:								// Z0
		{
			if(!Sensors.Turntable2InLineWithConveyorBelt2)			// S(Z0,!x8) = Z1
			{
				A3_NextState = AutomatTurnTable2_DriveRight;
			}
			else													// S(Z0,x8) = Z2
			{
				A3_NextState = AutomatTurnTable2_ArriveRight;
			}
			break;
		}

		case AutomatTurnTable2_DriveRight:							// Z1
		{
			if(Sensors.Turntable2InLineWithConveyorBelt2)			// S(Z1,x8) = Z2
			{
				A3_NextState = AutomatTurnTable2_ArriveRight;
			}
			else													// S(Z1,!x8) = Z1
			{
				A3_NextState = AutomatTurnTable2_DriveRight;
			}
			break;
		}

		case AutomatTurnTable2_ArriveRight:							// Z2
		{
			if(Sensors.ConveyorBelt2WorkpieceAvailable
			&& A2_State == AutomatMillingMachine_WaitBrickGo)		// S(Z1,x7&a2.Z6) = Z3
			{
				A3_NextState = AutomatTurnTable2_PullBrick;
			}
			else													// S(Z2,!x7#!a2.Z6) = Z2
			{
				A3_NextState = AutomatTurnTable2_ArriveRight;
			}
			break;
		}

		case AutomatTurnTable2_PullBrick:							// Z3
		{
			if(Sensors.Turntable2WorkpieceAvailable)				// S(Z3,x10) = Z4
			{
				A3_NextState = AutomatTurnTable2_DriveLeft;
			}
			else													// S(Z3,!x10) = Z3
			{
				A3_NextState = AutomatTurnTable2_PullBrick;
			}
			break;
		}

		case AutomatTurnTable2_DriveLeft:							// Z4
		{
			if(Sensors.Turntable2InLineWithConveyorBelt3)			// S(Z4,x9) = Z5
			{
				A3_NextState = AutomatTurnTable2_WaitForFree;
			}
			else													// S(Z4,!x9) = Z4
			{
				A3_NextState = AutomatTurnTable2_DriveLeft;
			}
			break;
		}

		case AutomatTurnTable2_WaitForFree:							// Z5
		{
			if(!Sensors.ConveyorBelt3WorkpieceAvailable)			// S(Z5,!x11) = Z6
			{
				A3_NextState = AutomatTurnTable2_MoveBrick;
			}
			else													// S(Z5,x11) = Z5
			{
				A3_NextState = AutomatTurnTable2_WaitForFree;
			}
			break;
		}

		case AutomatTurnTable2_MoveBrick:							// Z6
		{
			if(Sensors.ConveyorBelt3WorkpieceAvailable)				// S(Z6,x11) = Z0
			{
				A3_NextState = AutomatTurnTable2_Start;
			}
			else													// S(Z6,!x11) = Z6
			{
				A3_NextState = AutomatTurnTable2_MoveBrick;
			}
			break;
		}
	}

	//Assignment of the new States to the "Flip-Flops"

	A0_State = A0_NextState;
	A1_State = A1_NextState;
	A2_State = A2_NextState;
	A3_State = A3_NextState;


	//Set Actuators as default
	
	Actuators.TransportTableMoveToConveyorBelt3						= 0;	// y0
	Actuators.TransportTableMoveToConveyorBelt1						= 0;	// y1
	Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 = 0;	// y2
	Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 = 0;	// y3
	Actuators.ConveyorBelt1DriveBelt								= 0;	// y4
	Actuators.Turntable1RotateToConveyorBelt1						= 0;	// y5
	Actuators.Turntable1RotateToConveyorBelt2						= 0;	// y6
	Actuators.Turntable1DriveBelt									= 0;	// y7
	Actuators.ConveyorBelt2DriveBelt								= 0;	// y8
	Actuators.Turntable2RotateToConveyorBelt2						= 0;	// y9
	Actuators.Turntable2RotateToConveyorBelt_3						= 0;	// y10
	Actuators.Turntable2DriveBelt									= 0;	// y11
	Actuators.ConveyorBelt3DriveBelt								= 0;	// y12
	Actuators.MillingMachineApproachConveyorBelt_2					= 0;	// y13
	Actuators.MillingMachineRetreatFromConveyorBelt2				= 0;	// y14
	Actuators.MillingHeadRise										= 0;	// y15
	Actuators.MillingHeadLower										= 0;	// y16
	Actuators.MillingHeadDriveHead									= 0;	// y17


	//Output functions lambda for A0 (transport table)

	switch (A0_State)
	{

		case AutomatTransportTable_Start:											// Z0
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 0;	// y0
			Actuators.TransportTableMoveToConveyorBelt1						|= 0;	// y1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 0;	// y2
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 0;	// y3
			Actuators.ConveyorBelt1DriveBelt								|= 0;	// y4
			Actuators.ConveyorBelt3DriveBelt								|= 0;	// y12
			break;
		}
		
		case AutomatTransportTable_DriveRight:										// Z1
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 1;	// y0=1
			Actuators.TransportTableMoveToConveyorBelt1						|= 0;	// y1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 0;	// y2
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 0;	// y3
			Actuators.ConveyorBelt1DriveBelt								|= 0;	// y4
			Actuators.ConveyorBelt3DriveBelt								|= 0;	// y12
			break;
		}

		case AutomatTransportTable_ArriveRight:										// Z2
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 0;	// y0
			Actuators.TransportTableMoveToConveyorBelt1						|= 0;	// y1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 0;	// y2
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 0;	// y3
			Actuators.ConveyorBelt1DriveBelt								|= 0;	// y4
			Actuators.ConveyorBelt3DriveBelt								|= 0;	// y12
			break;
		}

		case AutomatTransportTable_PullBrick:										// Z3
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 0;	// y0
			Actuators.TransportTableMoveToConveyorBelt1						|= 0;	// y1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 0;	// y2
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 1;	// y3=1
			Actuators.ConveyorBelt1DriveBelt								|= 0;	// y4
			Actuators.ConveyorBelt3DriveBelt								|= 1;	// y12=1
			break;
		}

		case AutomatTransportTable_DriveLeft:										// Z4
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 0;	// y0
			Actuators.TransportTableMoveToConveyorBelt1						|= 1;	// y1=1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 0;	// y2
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 0;	// y3
			Actuators.ConveyorBelt1DriveBelt								|= 0;	// y4
			Actuators.ConveyorBelt3DriveBelt								|= 0;	// y12
			break;
		}

		case AutomatTransportTable_WaitForFree:										// Z5
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 0;	// y0
			Actuators.TransportTableMoveToConveyorBelt1						|= 0;	// y1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 0;	// y2
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 0;	// y3
			Actuators.ConveyorBelt1DriveBelt								|= 0;	// y4
			Actuators.ConveyorBelt3DriveBelt								|= 0;	// y12
			break;
		}
		
		case AutomatTransportTable_MoveBrick:										// Z6
		{
			Actuators.TransportTableMoveToConveyorBelt3						|= 0;	// y0
			Actuators.TransportTableMoveToConveyorBelt1						|= 0;	// y1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt1 |= 1;	// y2=1
			Actuators.TransportTableDriveConveyorBeltSimilarToConveyorBelt3 |= 0;	// y3
			Actuators.ConveyorBelt1DriveBelt								|= 1;	// y4=1
			Actuators.ConveyorBelt3DriveBelt								|= 0;	// y12
			break;
		}
		

	}

	//Output functions lambda for A1 (turntable 1)
	
	switch (A1_State)
	{
		case AutomatTurnTable1_Start:										// Z0
		{
			Actuators.ConveyorBelt1DriveBelt						|= 0;	// y4
			Actuators.Turntable1RotateToConveyorBelt1				|= 0;	// y5
			Actuators.Turntable1RotateToConveyorBelt2				|= 0;	// y6
			Actuators.Turntable1DriveBelt							|= 0;	// y7
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			break;
		}

		case AutomatTurnTable1_DriveRight:									// Z1
		{
			Actuators.ConveyorBelt1DriveBelt						|= 0;	// y4
			Actuators.Turntable1RotateToConveyorBelt1				|= 1;	// y5=1
			Actuators.Turntable1RotateToConveyorBelt2				|= 0;	// y6
			Actuators.Turntable1DriveBelt							|= 0;	// y7
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			break;
		}

		case AutomatTurnTable1_ArriveRight:									// Z2
		{
			Actuators.ConveyorBelt1DriveBelt						|= 0;	// y4
			Actuators.Turntable1RotateToConveyorBelt1				|= 0;	// y5
			Actuators.Turntable1RotateToConveyorBelt2				|= 0;	// y6
			Actuators.Turntable1DriveBelt							|= 0;	// y7
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			break;
		}
		case AutomatTurnTable1_PullBrick:									// Z3
		{
			Actuators.ConveyorBelt1DriveBelt						|= 1;	// y4=1
			Actuators.Turntable1RotateToConveyorBelt1				|= 0;	// y5
			Actuators.Turntable1RotateToConveyorBelt2				|= 0;	// y6
			Actuators.Turntable1DriveBelt							|= 1;	// y7=1
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			break;
		}
		
		case AutomatTurnTable1_DriveLeft:									// Z4
		{
			Actuators.ConveyorBelt1DriveBelt						|= 0;	// y4
			Actuators.Turntable1RotateToConveyorBelt1				|= 0;	// y5
			Actuators.Turntable1RotateToConveyorBelt2				|= 1;	// y6=1
			Actuators.Turntable1DriveBelt							|= 0;	// y7
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			break;
		}

		case AutomatTurnTable1_WaitForFree:									// Z5
		{
			Actuators.ConveyorBelt1DriveBelt						|= 0;	// y4
			Actuators.Turntable1RotateToConveyorBelt1				|= 0;	// y5
			Actuators.Turntable1RotateToConveyorBelt2				|= 0;	// y6
			Actuators.Turntable1DriveBelt							|= 0;	// y7
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			break;
		}

		case AutomatTurnTable1_MoveBrick:									// Z6
		{
			Actuators.ConveyorBelt1DriveBelt						|= 0;	// y4
			Actuators.Turntable1RotateToConveyorBelt1				|= 0;	// y5
			Actuators.Turntable1RotateToConveyorBelt2				|= 0;	// y6
			Actuators.Turntable1DriveBelt							|= 1;	// y7=1
			Actuators.ConveyorBelt2DriveBelt						|= 1;	// y8=1
			break;
		}
	}

	//Output functions lambda for A2 (milling machine)

	switch (A2_State)
	{
		case AutomatMillingMachine_Start:									// Z0
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 0;	// y13
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 0;	// y14
			Actuators.MillingHeadRise								|= 0;	// y15
			Actuators.MillingHeadLower								|= 0;	// y16
			Actuators.MillingHeadDriveHead							|= 0;	// y17
			break;
		}

		case AutomatMillingMachine_RiseMill:								// Z1
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 0;	// y13
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 0;	// y14
			Actuators.MillingHeadRise								|= 1;	// y15=1
			Actuators.MillingHeadLower								|= 0;	// y16
			Actuators.MillingHeadDriveHead							|= 0;	// y17
			break;
		}

		case AutomatMillingMachine_DriveToFront:							// Z2
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 0;	// y13
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 1;	// y14=1
			Actuators.MillingHeadRise								|= 0;	// y15
			Actuators.MillingHeadLower								|= 0;	// y16
			Actuators.MillingHeadDriveHead							|= 0;	// y17
			break;
		}
		case AutomatMillingMachine_LowerAndDrill:							// Z3
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 0;	// y13
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 0;	// y14
			Actuators.MillingHeadRise								|= 0;	// y15
			Actuators.MillingHeadLower								|= 1;	// y16=1
			Actuators.MillingHeadDriveHead							|= 1;	// y17=1
			break;
		}
		
		case AutomatMillingMachine_RiseAndDrill:							// Z4
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 0;	// y13
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 0;	// y14
			Actuators.MillingHeadRise								|= 1;	// y15=1
			Actuators.MillingHeadLower								|= 0;	// y16
			Actuators.MillingHeadDriveHead							|= 1;	// y17=1
			break;
		}

		case AutomatMillingMachine_DriveToBack:								// Z5
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 1;	// y13=1
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 0;	// y14
			Actuators.MillingHeadRise								|= 0;	// y15
			Actuators.MillingHeadLower								|= 0;	// y16
			Actuators.MillingHeadDriveHead							|= 0;	// y17
			break;
		}

		case AutomatMillingMachine_WaitBrickGo:								// Z6
		{
			Actuators.MillingMachineApproachConveyorBelt_2			|= 0;	// y13
			Actuators.MillingMachineRetreatFromConveyorBelt2		|= 0;	// y14
			Actuators.MillingHeadRise								|= 0;	// y15
			Actuators.MillingHeadLower								|= 0;	// y16
			Actuators.MillingHeadDriveHead							|= 0;	// y17
			break;
		}
	}

	//Output functions lambda for A3 (turntable 2)
	
	switch (A3_State)
	{
		case AutomatTurnTable2_Start:										// Z0
		{
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			Actuators.Turntable2RotateToConveyorBelt2				|= 0;	// y9
			Actuators.Turntable2RotateToConveyorBelt_3				|= 0;	// y10
			Actuators.Turntable2DriveBelt							|= 0;	// y11
			Actuators.ConveyorBelt3DriveBelt						|= 0;	// y12
			break;
		}

		case AutomatTurnTable2_DriveRight:									// Z1
		{
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			Actuators.Turntable2RotateToConveyorBelt2				|= 1;	// y9=1
			Actuators.Turntable2RotateToConveyorBelt_3				|= 0;	// y10
			Actuators.Turntable2DriveBelt							|= 0;	// y11
			Actuators.ConveyorBelt3DriveBelt						|= 0;	// y12
			break;
		}

		case AutomatTurnTable2_ArriveRight:									// Z2
		{
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			Actuators.Turntable2RotateToConveyorBelt2				|= 0;	// y9
			Actuators.Turntable2RotateToConveyorBelt_3				|= 0;	// y10
			Actuators.Turntable2DriveBelt							|= 0;	// y11
			Actuators.ConveyorBelt3DriveBelt						|= 0;	// y12
			break;
		}
		case AutomatTurnTable2_PullBrick:									// Z3
		{
			Actuators.ConveyorBelt2DriveBelt						|= 1;	// y8=1
			Actuators.Turntable2RotateToConveyorBelt2				|= 0;	// y9
			Actuators.Turntable2RotateToConveyorBelt_3				|= 0;	// y10
			Actuators.Turntable2DriveBelt							|= 1;	// y11=1
			Actuators.ConveyorBelt3DriveBelt						|= 0;	// y12
			break;
		}
		
		case AutomatTurnTable2_DriveLeft:									// Z4
		{
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			Actuators.Turntable2RotateToConveyorBelt2				|= 0;	// y9
			Actuators.Turntable2RotateToConveyorBelt_3				|= 1;	// y10=1
			Actuators.Turntable2DriveBelt							|= 0;	// y11
			Actuators.ConveyorBelt3DriveBelt						|= 0;	// y12
			break;
		}

		case AutomatTurnTable2_WaitForFree:									// Z5
		{
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			Actuators.Turntable2RotateToConveyorBelt2				|= 0;	// y9
			Actuators.Turntable2RotateToConveyorBelt_3				|= 0;	// y10
			Actuators.Turntable2DriveBelt							|= 0;	// y11
			Actuators.ConveyorBelt3DriveBelt						|= 0;	// y12
			break;
		}

		case AutomatTurnTable2_MoveBrick:									// Z6
		{
			Actuators.ConveyorBelt2DriveBelt						|= 0;	// y8
			Actuators.Turntable2RotateToConveyorBelt2				|= 0;	// y9
			Actuators.Turntable2RotateToConveyorBelt_3				|= 0;	// y10
			Actuators.Turntable2DriveBelt							|= 1;	// y11=1
			Actuators.ConveyorBelt3DriveBelt						|= 1;	// y12=1
			break;
		}
	}

}