// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#ifndef _USERDESIGN_H
    #define _USERDESIGN_H

    #include "../Main.h"
    extern void StateMachineInit(void);                                                     // This function initializes the state machine
    extern void StateMachineUpdate(void);                                                   // This function updated the state machine

// #########################################################################################
// #  State definitions for the Machines, notice: duplicate state identifiers NOT allowed  #
// #########################################################################################

	// A0 (transport table)
    typedef enum
    {
	    AutomatTransportTable_Start,
	    AutomatTransportTable_DriveRight,
	    AutomatTransportTable_ArriveRight,
	    AutomatTransportTable_PullBrick,
	    AutomatTransportTable_DriveLeft,
	    AutomatTransportTable_WaitForFree,
	    AutomatTransportTable_MoveBrick,
    } AutomatTransportTable_t;

	// A1 (turntable 1)
    typedef enum
    {
	    AutomatTurnTable1_Start,
	    AutomatTurnTable1_DriveRight,
	    AutomatTurnTable1_ArriveRight,
	    AutomatTurnTable1_PullBrick,
	    AutomatTurnTable1_DriveLeft,
	    AutomatTurnTable1_WaitForFree,
	    AutomatTurnTable1_MoveBrick,
    } AutomatTurnTable1_t;

	// A2 (milling machine)
    typedef enum
    {
	    AutomatMillingMachine_Start,
	    AutomatMillingMachine_RiseMill,
	    AutomatMillingMachine_DriveToFront,
	    AutomatMillingMachine_LowerAndDrill,
	    AutomatMillingMachine_RiseAndDrill,
	    AutomatMillingMachine_DriveToBack,
	    AutomatMillingMachine_WaitBrickGo,
    } AutomatMillingMachine_t;

	// A3 (turntable 2)
    typedef enum
    {
	    AutomatTurnTable2_Start,
	    AutomatTurnTable2_DriveRight,
	    AutomatTurnTable2_ArriveRight,
	    AutomatTurnTable2_PullBrick,
	    AutomatTurnTable2_DriveLeft,
	    AutomatTurnTable2_WaitForFree,
	    AutomatTurnTable2_MoveBrick,
    } AutomatTurnTable2_t;
    
#endif 