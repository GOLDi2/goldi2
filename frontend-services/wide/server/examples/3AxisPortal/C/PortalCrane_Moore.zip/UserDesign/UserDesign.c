// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include <util/delay.h>
#include "UserDesign.h"

AutomatStates_t State;


// ######################################################################################
// #  This function initializes the finite state machine with start state               #
// ######################################################################################
void StateMachineInit(void)
{
    State = StopDriveXMinus;
}

// ######################################################################################
// #  This function updates the current state of the finite state machine               #
// ######################################################################################
void StateMachineUpdate(void)
{
    switch (State)
    {
        case DriveXMinus:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = 1;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (!Sensors.XAxisAtPositionXMinus && Sensors.UserSwitch)
                State = DriveXMinus;
            else if(Sensors.XAxisAtPositionXMinus && Sensors.UserSwitch)
                State = DriveXPlus;
            else if(!Sensors.UserSwitch)
                State = StopDriveXMinus;
            
            break;
        }
        
        case DriveXPlus:
        {
            Actuators.XAxisDriveToXPlus     = 1;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (!Sensors.XAxisAtPositionXPlus && Sensors.UserSwitch)
                State = DriveXPlus;
            else if(Sensors.XAxisAtPositionXPlus && Sensors.UserSwitch)
                State = DriveXMinus;
            else if(!Sensors.UserSwitch)
                State = StopDriveXPlus;
            
            break;
        }
        
        case StopDriveXMinus:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (!Sensors.UserSwitch)
                State = StopDriveXMinus;
            else if(Sensors.UserSwitch && !Sensors.XAxisAtPositionXMinus)
                State = DriveXMinus;
            else if(Sensors.UserSwitch && Sensors.XAxisAtPositionXMinus)
                State = DriveXPlus;
            
            break;
        }

        case StopDriveXPlus:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (!Sensors.UserSwitch)
            State = StopDriveXPlus;
            else if(Sensors.UserSwitch && !Sensors.XAxisAtPositionXPlus)
            State = DriveXPlus;
            else if(Sensors.UserSwitch && Sensors.XAxisAtPositionXPlus)
            State = DriveXMinus;
            
            break;
        }

    }
}