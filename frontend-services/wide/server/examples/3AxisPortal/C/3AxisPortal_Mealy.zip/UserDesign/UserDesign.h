// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#ifndef _USERDESIGN_H
    #define _USERDESIGN_H

    #include "../Main.h"
    extern void StateMachineInit(void);                                                     // This function inits the state machine
    extern void StateMachineUpdate(void);                                                   // This function updated the state machine

// ######################################################################################
// #  Add a new state for state maschine here                                           #
// ######################################################################################
    typedef enum
    {
        Z0_WaitForFallingEdge,                                                                 // Z0 - wait for 1/0 edge
        Z1_DriveXMinusYMinus,                                                                  // Z1 - drive to left/down
        Z2_DriveYPlusXPlus                                                                     // Z2 - drive to up/right
    } AutomatStates_t;
    
#endif 