// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include <util/delay.h>
#include "UserDesign.h"

AutomatStates_t State;


// ######################################################################################
// #  This function initializes the finite state machine with start state               #
// ######################################################################################
void StateMachineInit(void)
{
    State = Z0_WaitForFallingEdge;
}

// ######################################################################################
// #  This function updates the current state of the finite state machine               #
// ######################################################################################
void StateMachineUpdate(void)
{
    switch (State)
    {
        case Z0_WaitForFallingEdge:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (!Sensors.UserSwitch)
                State = Z1_DriveXMinusYMinus;
            //else 
            //    State = Z0_WaitForFallingEdge;
            
            break;
        }
        
        case Z1_DriveXMinusYMinus:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = !Sensors.XAxisAtPositionXMinus;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = !Sensors.YAxisAtPositionYMinus;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (Sensors.XAxisAtPositionXMinus && Sensors.YAxisAtPositionYMinus)
                State = Z2_DriveYPlusXPlus;
            //else 
            //    State = Z1_DriveXMinusYMinus;
            
            break;
        }
        
        case Z2_DriveYPlusXPlus:
        {
            Actuators.XAxisDriveToXPlus     = Sensors.YAxisAtPositionYPlus && !Sensors.XAxisAtPositionXPlus;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = !Sensors.YAxisAtPositionYPlus;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (Sensors.XAxisAtPositionXPlus && Sensors.UserSwitch)
                State = Z0_WaitForFallingEdge;
            //else 
            //    State = Z2_DriveYPlusXPlus;
            
            break;
        }
    }
}