// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include <util/delay.h>
#include "UserDesign.h"

AutomatUpDownStates_t A0_State;		//Machine handling the elevator cabin
AutomatUpDownStates_t A0_NextState;

AutomatDoorStates_t A1_State;		//Machine handling the doors
AutomatDoorStates_t A1_NextState;


// ######################################################################################
// #  This function initializes the finite state machine with start state               #
// ######################################################################################
void StateMachineInit(void)
{
    A0_State =		AutomatUpDown_DriveUp;
    A0_NextState =	AutomatUpDown_DriveUp;

	A1_State =		AutomatDoor_Init;
	A1_NextState =	AutomatDoor_Init;
}

// ######################################################################################
// #  This function updates the current state of the finite state machine               #
// ######################################################################################
void StateMachineUpdate(void)
{

	//Transition function delta for A0
    switch (A0_State)
     {
		 //We're going up
         case AutomatUpDown_DriveUp:
         {
			 //We're not upstairs yet, we have to continue
             if (!Sensors.ElevatorOnFloor_4)
                A0_NextState = AutomatUpDown_DriveUp;
             //We've reached the top floor, now we wait for the doors
			 else
                A0_NextState = AutomatUpDown_Wait;
             
             break;
         }

         //We're going down
         case AutomatUpDown_DriveDown:
         {
			//We're not downstairs yet, we have to continue
             if (!Sensors.ElevatorOnFloor1)
				A0_NextState = AutomatUpDown_DriveDown;
             //We've reached the bottom floor, now we wait for the doors
			 else
				A0_NextState = AutomatUpDown_Wait;
             break;
         }
		 //Were waiting for the doors to be closed again
		 case  AutomatUpDown_Wait:
		 {
			//Doors are closed and we are on bottom floor -> let's go up
			if(A1_State == AutomatDoor_Rdy && Sensors.ElevatorOnFloor1)
				A0_NextState = AutomatUpDown_DriveUp;
			//Doors are closed and we are on top floor -> let's go dowm
			else if(A1_State == AutomatDoor_Rdy && Sensors.ElevatorOnFloor_4)
				A0_NextState = AutomatUpDown_DriveDown;
			//Doors are not ready yet
			else
				A0_NextState = AutomatUpDown_Wait;
			break;
		 }
     }

	 //Transition function delta for A1
	 switch (A1_State)
	 {
		 case AutomatDoor_Init:
		 {
			//A0 is waiting for the doors
			if(A0_State == AutomatUpDown_Wait && (Sensors.ElevatorOnFloor1 || Sensors.ElevatorOnFloor_4))
				A1_NextState = AutomatDoor_WaitforOpen;
			else
				A1_NextState = AutomatDoor_Init;
			break;
		 }
		 case AutomatDoor_WaitforOpen:
		 {
			//Check if doors are open
			if(!(Sensors.Floor1DoorOpen || Sensors.Floor4DoorOpen))
			{
				//Doors are still not open
				A1_NextState = AutomatDoor_WaitforOpen;
			}
			else
			{
				//At least one door is open
				A1_NextState = AutomatDoor_WaitforClose;
			}
			break;
		 }
		 case AutomatDoor_WaitforClose:
		 {
			//Check if doors are closed
			if(Sensors.Floor1DoorClosed && Sensors.Floor4DoorClosed)
			{
				//Both doors are closed
				A1_NextState = AutomatDoor_Rdy;
			}
			else
			{
				//At least one door is still open
				A1_NextState = AutomatDoor_WaitforClose;
			}
			break;
		 }
		 case AutomatDoor_Rdy:
		 {
			//Check if we left top or bottom floor
			if(Sensors.ElevatorOnFloor1 || Sensors.ElevatorOnFloor_4)
			{
				//Still there
				A1_NextState = AutomatDoor_Rdy;
			}
			else
			{
				//We're moving
				A1_NextState = AutomatDoor_Init;
			}
		 }
	 }


	 //Assignment of the new States to the "Flip-Flops"
	 A0_State = A0_NextState;
	 A1_State = A1_NextState;


	 //Output functions lambda for A0
	 switch (A0_State)
	 {
		 case AutomatUpDown_DriveUp:
		 {
			//Drive the elevator upwards when not at top floor and emergency stop is depressed
			Actuators.DriveUpwards     = !Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;
			//Light up indicator when not at top floor and emergency stop is depressed 
			Actuators.DriveDirectionDisplayUpward = !Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;
			
			Actuators.DriveDirectionDisplayDownward = 0;
			Actuators.DriveDownwards   = 0;
			Actuators.IndicatorDisplayFloor1 = 0;
			Actuators.IndicatorDisplayFloor4 = 0;
			break;
		 }
		 
		 case AutomatUpDown_DriveDown:
		 {
			 
			 
			 //Drive the elevator downwards when not at bottom floor and emergency stop is depressed
			 Actuators.DriveDownwards   = !Sensors.ElevatorOnFloor1 && !Sensors.ElevatorControlEmergencyStop;
			 //Light up indicator when not at bottom floor and emergency stop is depressed 
			 Actuators.DriveDirectionDisplayDownward = !Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;

			 Actuators.DriveDirectionDisplayUpward = 0;
			 Actuators.DriveUpwards     = 0;
			 Actuators.IndicatorDisplayFloor1 = 0;
			 Actuators.IndicatorDisplayFloor4 = 0;
			 break;
		 }
		 case AutomatUpDown_Wait:
		 {
			Actuators.DriveDownwards = 0;
			Actuators.DriveUpwards = 0;
			Actuators.DriveDirectionDisplayDownward = 0;
			Actuators.DriveDirectionDisplayUpward = 0;
			Actuators.IndicatorDisplayFloor1 = Sensors.ElevatorOnFloor1;
			Actuators.IndicatorDisplayFloor4 = Sensors.ElevatorOnFloor_4;
			break;
		 }
	 }

	 //Output functions lambda for A1
	 switch (A1_State)
	 {
		case  AutomatDoor_Init:
		{
			Actuators.DoorFloor1Close = 0;
			Actuators.DoorFloor1Open = 0;
			Actuators.DoorFloor4Close = 0;
			Actuators.DoorFloor4Open = 0;
			break;
		}
		case AutomatDoor_WaitforOpen:
		{
			Actuators.DoorFloor1Close = 0;
			Actuators.DoorFloor1Open =	Sensors.ElevatorOnFloor1 && !Sensors.ElevatorControlEmergencyStop;
			Actuators.DoorFloor4Close = 0;
			Actuators.DoorFloor4Open =	Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;
			break;
		}
		case AutomatDoor_WaitforClose:
		{
			Actuators.DoorFloor1Close = Sensors.ElevatorOnFloor1 && !Sensors.ElevatorControlEmergencyStop;
			Actuators.DoorFloor1Open =	0;
			Actuators.DoorFloor4Close = Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;
			Actuators.DoorFloor4Open =	0;
			break;
		}
		case AutomatDoor_Rdy:
		{
			Actuators.DoorFloor1Close = 0;
			Actuators.DoorFloor1Open = 0;
			Actuators.DoorFloor4Close = 0;
			Actuators.DoorFloor4Open = 0;
			break;
		}
	 }

	 //Static outputs
	 Actuators.ElevatorControlEmergencyStop = Sensors.ElevatorControlEmergencyStop;
	 

}