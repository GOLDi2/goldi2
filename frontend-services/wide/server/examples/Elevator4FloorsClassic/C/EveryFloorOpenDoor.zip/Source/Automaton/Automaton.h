#ifndef AUTOMAT_H_
#define AUTOMAT_H_

#include "Elevator4Floor.h"

typedef enum
{
	Init,
	DriveToFloor1Down,
	DriveToFloor2Up,
	DriveToFloor3Up,
	DriveToFloor4Up,
	OpenDoorsFloor1,
	OpenDoorsFloor2,
	OpenDoorsFloor3,
	OpenDoorsFloor4,
	CloseDoorsFloor1,
	CloseDoorsFloor2,
	CloseDoorsFloor3,
	CloseDoorsFloor4,
	Wait3SecondsFloor1,
	Wait3SecondsFloor2,
	Wait3SecondsFloor3,
	Wait3SecondsFloor4,
}AutomatStates_t;

extern void StateMachineInit(void);		// This function init the state machine.
extern void StateMachineUpdate(void);	// This function updated the state machine.


#endif /* AUTOMAT_H_ */