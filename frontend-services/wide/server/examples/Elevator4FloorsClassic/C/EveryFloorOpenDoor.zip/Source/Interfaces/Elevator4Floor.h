#ifndef _ELEVATOR4FLOOR
#define _ELEVATOR4FLOOR

typedef struct
{
	unsigned ElevatorOnFloor1:1;
    unsigned ElevatorOnFloor2:1;
    unsigned ElevatorOnFloor3:1;
    unsigned ElevatorAboveFloor1:1;
    unsigned ElevatorBelowFloor2:1;
    unsigned ElevatorAboveFloor2:1;
    unsigned ElevatorBelowFloor3:1;
    unsigned Floor1_DoorOpen:1;
    unsigned Floor1_DoorClosed:1;
    unsigned Floor2_DoorOpen:1;
    unsigned Floor2_DoorClosed:1;
    unsigned Floor3_DoorOpen:1;
    unsigned Floor3_DoorClosed:1;
    unsigned LightBarrierFloor1:1;
    unsigned LightBarrierFloor2:1;
    unsigned LightBarrierFloor3:1;
    unsigned CallButtOnFloor1:1;
    unsigned CallButtOnFloor2Up:1;
    unsigned CallButtOnFloor2Down:1;
    unsigned CallButtOnFloor3:1;
    unsigned ElevatorcOntrol_Floor1:1;
    unsigned ElevatorcOntrol_Floor2:1;
    unsigned ElevatorcOntrol_Floor3:1;
    unsigned ElevatorcOntrol_Alert:1;
    unsigned ElevatorcOntrol_EmergencyStop:1;
    unsigned SimulationOverload:1;
    unsigned ElevatorOnFloor4:1;
    unsigned ElevatorAboveFloor3:1;
    unsigned ElevatorBelowFloor4:1;
    unsigned Floor4_DoorOpen:1;
    unsigned Floor4_DoorClosed:1;
    unsigned LightBarrierFloor4:1;
	unsigned int reserve1;
} Sensor_t;

typedef struct
{
	unsigned DriveUpwards:1;
    unsigned DriveDownwards:1;
    unsigned DriveSlowly:1;
    unsigned DoorFloor1_Open:1;
    unsigned DoorFloor1_Close:1;
    unsigned DoorFloor2_Open:1;
    unsigned DoorFloor2_Close:1;
    unsigned DoorFloor3_Open:1;
    unsigned DoorFloor3_Close:1;
    unsigned CallDisplayFloor1:1;
    unsigned CallDisplayFloor2_Upward:1;
    unsigned CallDisplayFloor2_Downward:1;
    unsigned CallDisplayFloor3_Downward:1;
    unsigned IndicatorDisplayFloor1:1;
    unsigned IndicatorDisplayFloor2:1;
    unsigned IndicatorDisplayFloor3:1;
    unsigned DrivedirectionDisplay_Downward:1;
    unsigned DrivedirectionDisplay_Upward:1;
    unsigned ElevatorControl_IndicatorDisplayFloor1:1;
    unsigned ElevatorControl_IndicatorDisplayFloor2:1;
    unsigned ElevatorControl_IndicatorDisplayFloor3:1;
    unsigned ElevatorControl_Alert:1;
    unsigned ElevatorControl_EmergencyStop:1;
    unsigned ElevatorControl_Overload:1;
    unsigned DoorFloor4_Open:1;
    unsigned DoorFloor4_Close:1;
    unsigned CallDisplayFloor3_Upwards:1;
    unsigned CallDisplayFloor4:1;
    unsigned IndicatorDisplayFloor4:1;
    unsigned CallDisplayControl_ElevatorControl	:1;

    unsigned reserve1:1;
    unsigned reserve2:1;
	unsigned int reserve3;
} Actuator_t;

#define SensorPointer (uint8_t *)&Sensors
#define ActuatorPointer (uint8_t *)&Actuators

extern Sensor_t Sensors;
extern Actuator_t Actuators;

#endif