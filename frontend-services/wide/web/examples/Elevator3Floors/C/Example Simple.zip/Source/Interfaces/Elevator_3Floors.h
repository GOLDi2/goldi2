#ifndef ELEVATOR_3FLOORS_H
#define ELEVATOR_3FLOORS_H

typedef struct
{
    unsigned cabin_to_Z_plus:1;                                                   // y 0
    unsigned cabin_to_Z_minus:1;                                                  // y 1
    unsigned cabin_slow:1;                                                        // y 2
    unsigned to_open_door_ground_floor:1;                                         // y 3
    unsigned to_close_door_ground_floor:1;                                        // y 4
    unsigned to_open_door_1_floor:1;                                              // y 5
    unsigned to_close_door_1_floor:1;                                             // y 6
    unsigned to_open_door_2_floor:1;                                              // y 7
    unsigned to_close_door_2_floor:1;                                             // y 8
    unsigned call_display_ground_floor:1;                                         // y 9
    unsigned call_display_1_floor_upstairs:1;                                     // y10
    unsigned call_display_1_floor_downward:1;                                     // y11
    unsigned call_display_2_floor:1;                                              // y12
    unsigned indicator_display_ground_floor:1;                                    // y13
    unsigned indicator_display_1_floor:1;                                         // y14
    unsigned indicator_display_2_floor:1;                                         // y15
    unsigned drive_direction_display_downward:1;                                  // y16
    unsigned drive_direction_display_upstairs:1;                                  // y17
    unsigned call_display_ground_floor_LED_operator_panel:1;                      // y18
    unsigned call_display_1_floor_LED_operator_panel:1;                           // y19
    unsigned call_display_2_floor_LED_operator_panel:1;                           // y20
    unsigned alert_LED_operator_panel:1;                                          // y21
    unsigned emergency_stop_LED_operator_panel:1;                                 // y22
    unsigned overload_LED_operator_panel:1;                                       // y23
	
	unsigned char reserve1;	//8 bit
	unsigned int reserve2;	//16 bit
} Actuator_t;

typedef struct
{
    unsigned cabin_pos_ground_floor:1;                                            // x 0
    unsigned cabin_pos_1_floor:1;                                                 // x 1
    unsigned cabin_pos_2_floor:1;                                                 // x 2
    unsigned switchover_slow_ground_floor:1;                                      // x 3
    unsigned switchover_slow_1_floor_from_the_bottom:1;                           // x 4
    unsigned switchover_slow_1_floor_from_the_top:1;                              // x 5
    unsigned switchover_slow_2_floor:1;                                           // x 6
    unsigned door_ground_floor_open:1;                                            // x 7
    unsigned door_ground_floor_closed:1;                                          // x 8
    unsigned door_1_floor_open:1;                                                 // x 9
    unsigned door_1_floor_closed:1;                                               // x10
    unsigned door_2_floor_open:1;                                                 // x11
    unsigned door_2_floor_closed:1;                                               // x12
    unsigned light_barrier_ground_floor:1;                                        // x13
    unsigned light_barrier_1_floor:1;                                             // x14
    unsigned light_barrier_2_floor:1;                                             // x15
    unsigned call_button_ground_floor:1;                                          // x16
    unsigned call_button_1_floor_downward:1;                                      // x17
    unsigned call_button_1_floor_upstairs:1;                                      // x18
    unsigned call_button_2_floor:1;                                               // x19
    unsigned call_button_ground_floor_operator_panel:1;                           // x20
    unsigned call_button_1_floor_operator_panel:1;                                // x21
    unsigned call_button_2_floor_operator_panel:1;                                // x22
    unsigned alert_operator_panel:1;                                              // x23
    unsigned emergency_stop_operator_panel:1;                                     // x24
    unsigned Simulation_overload:1;                                               // x25

	unsigned reserve0:6;
	unsigned int reserve2;	//16 bit
} Sensor_t;

#define SensorPointer (uint8_t *)&Sensors
#define ActuatorPointer (uint8_t *)&Actuators

extern Sensor_t Sensors;
extern Actuator_t Actuators;

#endif /* ELEVATOR_3FLOORS_H */