#include "Elevator_3Floors.h"

Sensor_t Sensors;
Actuator_t Actuators;

void Elevator_3Floors_Init(void)
{
	
}