#ifndef AUTOMAT_H_
#define AUTOMAT_H_

#include "Elevator_3Floors.h"

typedef enum
{
	z_DriveToBottom,
	z_OpenDoorFloor1,
	z_Wait3SecFloor1,
	z_CloseDoorFloor1,
	z_DriveToFloor3,
	z_OpenDoorFloor3,
	z_Wait3SecFloor3,
	z_CloseDoorFloor3	
}AutomatStates_t;

extern void StateMachineInit(void);		// This function init the state machine.
extern void StateMachineUpdate(void);	// This function updated the state machine.


#endif /* AUTOMAT_H_ */