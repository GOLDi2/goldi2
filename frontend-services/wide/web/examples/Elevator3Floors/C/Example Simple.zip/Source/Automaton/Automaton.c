#include "Automaton.h"
#include <util/delay.h>

AutomatStates_t State;
/**
This function init the state machine.
*/
void StateMachineInit(void)
{
	State= z_DriveToBottom;
}

/**
This function updated the state machine.
*/
void StateMachineUpdate(void)
{
	switch (State)
	{
		case z_DriveToBottom:
			if (Sensors.cabin_pos_ground_floor == 1) 
			{
				State = z_OpenDoorFloor1;
			}
			
			Actuators.cabin_to_Z_minus = 1;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 0;
			
			break;
			
		case z_OpenDoorFloor1:
			if (Sensors.door_ground_floor_open == 0)
			{
				State = z_Wait3SecFloor1;
			}
			Actuators.cabin_to_Z_minus = 0;
				
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 1;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 0;
						
			break;
			
		case z_Wait3SecFloor1:
			_delay_ms(3000);
			State = z_CloseDoorFloor1;
			
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 0;
			
			break;
			
		case z_CloseDoorFloor1:
			if (Sensors.door_ground_floor_closed == 0)
			{
				State = z_DriveToFloor3;
			}
			
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 1;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 0;
			
			break;

		case z_DriveToFloor3:
			if (Sensors.cabin_pos_2_floor == 1)
			{
				State = z_OpenDoorFloor3;
			}
		
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 1;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 0;
		
			break;
		
		case z_OpenDoorFloor3:
			if (Sensors.door_2_floor_open == 0)
			{
				State = z_Wait3SecFloor3;
			}
		
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 1;
			Actuators.to_close_door_2_floor = 0;
		
			break;
		
		case z_Wait3SecFloor3:
			_delay_ms(3000);
			State = z_CloseDoorFloor3;
			
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 0;
			
			break;
		
		case z_CloseDoorFloor3:
			if (Sensors.door_2_floor_closed == 0)
			{
				State = z_DriveToBottom;
			}
			
			Actuators.cabin_to_Z_minus = 0;
			Actuators.to_open_door_ground_floor = 0;
			Actuators.to_close_door_ground_floor = 0;
			Actuators.cabin_to_Z_plus = 0;
			Actuators.to_open_door_2_floor = 0;
			Actuators.to_close_door_2_floor = 1;
			
			break;	
	}
}