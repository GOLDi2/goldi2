// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#ifndef _USERDESIGN_H
    #define _USERDESIGN_H

    #include "../Main.h"
    extern void StateMachineInit(void);                                                     // This function inits the state machine
    extern void StateMachineUpdate(void);                                                   // This function updated the state machine

// ######################################################################################
// #  Add a new state for state maschine here                                           #
// ######################################################################################
    typedef enum
    {
        Z0_WaitForFallingEdge,                                                                 // Z0 - wait for 1/0 edge
        Z1_DriveXMinusYMinus,                                                                  // Z1 - drive to X- and Y-
        Z2_DriveXMinus,                                                                        // Z2 - drive to X-
        Z3_DriveYMinus,                                                                        // Z3 - drive to Y-
        Z4_DriveYPlus,                                                                         // Z4 - drive to Y+
        Z5_DriveXPlus,                                                                         // Z5 - drive to X+
        Z6_WaitForUserSwich                                                                    // Z6 - wait for UserSwich = 1
    } AutomatStates_t;
    
#endif 