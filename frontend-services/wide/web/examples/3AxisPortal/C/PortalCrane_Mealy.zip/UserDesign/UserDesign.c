// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include <util/delay.h>
#include "UserDesign.h"

AutomatStates_t State;


// ######################################################################################
// #  This function initializes the finite state machine with start state               #
// ######################################################################################
void StateMachineInit(void)
{
    State = Z0_Init;
}

// ######################################################################################
// #  This function updates the current state of the finite state machine               #
// ######################################################################################
void StateMachineUpdate(void)
{
    switch (State)
    {
        case Z0_Init:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (!Sensors.XAxisAtPositionXMinus)
                State = Z1_DriveXMinus;
            else 
                State = Z2_DriveXPlus;
            
            break;
        }
        
        case Z1_DriveXMinus:
        {
            Actuators.XAxisDriveToXPlus     = 0;
            Actuators.XAxisDriveToXMinus    = Sensors.UserSwitch;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (Sensors.XAxisAtPositionXMinus)
                State = Z2_DriveXPlus;
            //else if(!Sensors.XAxisAtPositionXMinus)
            //    State = Z1_DriveXMinus;
            
            break;
        }
        
        case Z2_DriveXPlus:
        {
            Actuators.XAxisDriveToXPlus     = Sensors.UserSwitch;
            Actuators.XAxisDriveToXMinus    = 0;
            Actuators.YAxisDriveToYPlus     = 0;
            Actuators.YAxisDriveToYMinus    = 0;
            Actuators.ZAxisDriveToZPlus     = 0;
            Actuators.ZAxisDriveToZMinus    = 0;
            Actuators.Magnet                = 0;
            
            if (Sensors.XAxisAtPositionXPlus)
                State = Z1_DriveXMinus;
            //else if(!Sensors.XAxisAtPositionXPlus)
            //    State = Z2_DriveXPlus;
            
            break;
        }
    }
}