#ifndef _3AXISPORTAL_H
#define _3AXISPORTAL_H

typedef struct
{
    unsigned XAxis_Crane_position_right:1;
    unsigned XAxis_Crane_position_left:1;
    unsigned XAxis_Crane_at_reference_position:1;
    unsigned YAxis_Crane_position_back:1;
    unsigned YAxis_Crane_postition_front:1;
    unsigned YAxis_Crane_at_reference_position:1;
    unsigned ZAxis_Crane_at_position_up:1;
    unsigned ZAxis_Crane_at_position_down:1;
    unsigned Proximity_sensor:1;
    unsigned User_button:1;
    unsigned int abs_position_x;
    unsigned int abs_position_y;
    unsigned Reserve_01:1;
    unsigned Reserve_02:1;
    unsigned Reserve_03:1;
    unsigned Reserve_04:1;
    unsigned Reserve_05:1;
    unsigned Reserve_06:1;
} Sensor_t;          
             
typedef struct
{
    unsigned Crane_drive_pX_right:1;
    unsigned Crane_drive_mX_left:1;
    unsigned Crane_drive_pY_back:1;
    unsigned Crane_drive_pY_front:1;
    unsigned Crane_drive_pZ_up:1;
    unsigned Crane_drive_mZ_down:1;
    unsigned Electromagnet:1;
    unsigned Reserve_01:1;
    unsigned char Reserve_02;
    unsigned int Reserve_03;
    unsigned int Reserve_04;
} Actuator_t;

#define SensorPointer (uint8_t *)&Sensors
#define ActuatorPointer (uint8_t *)&Actuators

extern Sensor_t Sensors;
extern Actuator_t Actuators;

#endif // _3AXISPORTAL_H 