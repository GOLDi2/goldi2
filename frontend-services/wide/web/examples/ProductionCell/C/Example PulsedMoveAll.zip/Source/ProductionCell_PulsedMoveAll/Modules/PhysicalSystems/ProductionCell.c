#include "ProductionCell.h"

Sensor_t Sensors;
Actuator_t Actuators;
