#ifndef _PRODUCTIONCELL_H
#define _PRODUCTIONCELL_H

typedef struct
{
    unsigned Transport_table_in_line_with_conveyor_belt_3_low_active:1;
    unsigned Transport_table_in_line_with_conveyor_belt_1_low_active:1;
    unsigned Transport_table_workpiece_available:1;
    unsigned Conveyor_belt_1_workpiece_available:1;
    unsigned Turntable_1_in_line_with_conveyor_belt_1_low_active:1;
    unsigned Turntable_1_in_line_with_conveyor_belt_2_low_active:1;
    unsigned Turntable_1_workpiece_available:1;
    unsigned Conveyor_belt_2_workpiece_available:1;
    unsigned Turntable_2_in_line_with_conveyor_belt_2_low_active:1;
    unsigned Turntable_2_in_line_with_conveyor_belt_3_low_active:1;
    unsigned Turntable_2_workpiece_available:1;
    unsigned Conveyor_belt_3_workpiece_available:1;
    unsigned Milling_machine_away_from_conveyor_belt_2_low_active:1;
    unsigned Milling_machine_at_conveyor_belt_2_low_active:1;
    unsigned Milling_head_is_up_low_active:1;
    unsigned Milling_head_is_down_low_active:1;
    unsigned Emergency_Stop:1;
    unsigned Reserve_01:1;
    unsigned Reserve_02:1;
    unsigned Reserve_03:1;
    unsigned Reserve_04:1;
    unsigned Reserve_05:1;
    unsigned Reserve_06:1;
    unsigned Reserve_07:1;
    unsigned char Reserve_08;
    unsigned int Reserve_09;
} Sensor_t;          
             
typedef struct
{
    unsigned Transport_table_move_to_conveyor_belt_3:1;
    unsigned Transport_table_move_to_conveyor_belt_1:1;
    unsigned Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_1:1;
    unsigned Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_3:1;
    unsigned Conveyor_belt_1_drive_belt:1;
    unsigned Turntable_1_rotate_to_conveyor_belt_1:1;
    unsigned Turntable_1_rotate_to_conveyor_belt_2:1;
    unsigned Turntable_1_drive_belt:1;
    unsigned Conveyor_belt_2_drive_belt:1;
    unsigned Turntable_2_rotate_to_conveyor_belt_2:1;
    unsigned Turntable_2_rotate_to_conveyor_belt_3:1;
    unsigned Turntable_2_drive_belt:1;
    unsigned Conveyor_belt_3_drive_belt:1;
    unsigned Milling_machine_approach_conveyor_belt_2:1;
    unsigned Milling_machine_retreat_from_conveyor_belt_2:1;
    unsigned Milling_head_rise:1;
    unsigned Milling_head_lower:1;
    unsigned Milling_head_drive_head:1;
    unsigned Reserve_01:1;
    unsigned Reserve_02:1;
    unsigned Reserve_03:1;
    unsigned Reserve_04:1;
    unsigned Reserve_05:1;
    unsigned Reserve_06:1;
    unsigned char Reserve_07;
    unsigned int Reserve_08;
} Actuator_t;

#define SensorPointer (uint8_t *)&Sensors
#define ActuatorPointer (uint8_t *)&Actuators

extern Sensor_t Sensors;
extern Actuator_t Actuators;

#endif // _PRODUCTIONCELL_H 