#include "Automaton.h"
#include <util/delay.h>

#include "../Modules/PhysicalSystems/Elevator4Floor.h"

typedef enum
{
	Init,
	DriveToFloor1Down,
	DriveToFloor2Up,
	DriveToFloor3Up,
	DriveToFloor4Up,
	OpenDoorsFloor1,
	OpenDoorsFloor2,
	OpenDoorsFloor3,
	OpenDoorsFloor4,
	CloseDoorsFloor1,
	CloseDoorsFloor2,
	CloseDoorsFloor3,
	CloseDoorsFloor4,
	Wait3SecondsFloor1,
	Wait3SecondsFloor2,
	Wait3SecondsFloor3,
	Wait3SecondsFloor4,
}AutomatStates_t;

AutomatStates_t State;


void StateMachineInit(void)
{
    State= Init;
	
	Actuators.DriveUpwards                            = 0;
	Actuators.DriveDownwards                          = 0;
	Actuators.DriveSlowly                             = 0;
	Actuators.DoorFloor1_Open                         = 0;
	Actuators.DoorFloor1_Close                        = 0;
	Actuators.DoorFloor2_Open                         = 0;
	Actuators.DoorFloor2_Close                        = 0;
	Actuators.DoorFloor3_Open                         = 0;
	Actuators.DoorFloor3_Close                        = 0;
	Actuators.CallDisplayFloor1                       = 0;
	Actuators.CallDisplayFloor2_Upward                = 0;
	Actuators.CallDisplayFloor2_Downward              = 0;
	Actuators.CallDisplayFloor3_Downward              = 0;
	Actuators.IndicatorDisplayFloor1                  = 0;
	Actuators.IndicatorDisplayFloor2                  = 0;
	Actuators.IndicatorDisplayFloor3                  = 0;
	Actuators.DrivedirectionDisplay_Downward          = 0;
	Actuators.DrivedirectionDisplay_Upward            = 0;
	Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
	Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
	Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
	Actuators.ElevatorControl_Alert                   = 0;
	Actuators.ElevatorControl_EmergencyStop           = 0;
	Actuators.ElevatorControl_Overload                = 0;
	Actuators.DoorFloor4_Open                         = 0;
	Actuators.DoorFloor4_Close                        = 0;
	Actuators.CallDisplayFloor3_Upwards               = 0;
	Actuators.CallDisplayFloor4                       = 0;
	Actuators.IndicatorDisplayFloor4                  = 0;
	Actuators.CallDisplayControl_ElevatorControl      = 0;
}

void StateMachineUpdate(void)
{
    switch (State)
    {
        case Init:
            {
                if (Sensors.ElevatorOnFloor1)
                    State = OpenDoorsFloor1;
                else
                    State = DriveToFloor1Down;
                
                break;
            }
            
        case DriveToFloor1Down:
            {
                if (Sensors.ElevatorOnFloor1)
                    State = OpenDoorsFloor1;
                
                break;
            }
            
        case OpenDoorsFloor1:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 1;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor1_DoorOpen)
                    State = Wait3SecondsFloor1;
                
                break;
            }  
        
        case Wait3SecondsFloor1:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                _delay_ms(3000);
                State = CloseDoorsFloor1;
                
                break;
            }
        
        case CloseDoorsFloor1:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 1;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor1_DoorClosed)
                    State = DriveToFloor2Up;
                
                break;
            }
        
        case DriveToFloor2Up:
            {
                Actuators.DriveUpwards                            = 1;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (Sensors.ElevatorOnFloor2)
                    State = OpenDoorsFloor2;
                
                break;
            }

        case OpenDoorsFloor2:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 1;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor2_DoorOpen)
                    State = Wait3SecondsFloor2;
                
                break;
            }
        
        case Wait3SecondsFloor2:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                _delay_ms(3000);
                State = CloseDoorsFloor2;
                
                break;
            }
        
        case CloseDoorsFloor2:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 1;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor2_DoorClosed)
                    State = DriveToFloor3Up;
                
                break;
            }
        
        case DriveToFloor3Up:
            {
                Actuators.DriveUpwards                            = 1;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (Sensors.ElevatorOnFloor3)
                    State = OpenDoorsFloor3;
                
                break;
            }
        
        case OpenDoorsFloor3:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 1;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor3_DoorOpen)
                    State = Wait3SecondsFloor3;
                
                break;
            }
            
        case Wait3SecondsFloor3:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                _delay_ms(3000);
                State = CloseDoorsFloor3;
                
                break;
            } 

        case CloseDoorsFloor3:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 1;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor3_DoorClosed)
                    State = DriveToFloor4Up;
                
                break;
            }            
        
        case DriveToFloor4Up:
            {
                Actuators.DriveUpwards                            = 1;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (Sensors.ElevatorOnFloor4)
                    State = OpenDoorsFloor4;
                
                break;
            }  
            
        case OpenDoorsFloor4:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 1;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor4_DoorOpen)
                    State = Wait3SecondsFloor4;
                
                break;
            }    
            
        case Wait3SecondsFloor4:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 0;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                _delay_ms(3000);
                State = CloseDoorsFloor4;
                
                break;
            }    
            
        case CloseDoorsFloor4:
            {
                Actuators.DriveUpwards                            = 0;
                Actuators.DriveDownwards                          = 0;
                Actuators.DriveSlowly                             = 0;
                Actuators.DoorFloor1_Open                         = 0;
                Actuators.DoorFloor1_Close                        = 0;
                Actuators.DoorFloor2_Open                         = 0;
                Actuators.DoorFloor2_Close                        = 0;
                Actuators.DoorFloor3_Open                         = 0;
                Actuators.DoorFloor3_Close                        = 0;
                Actuators.CallDisplayFloor1                       = 0;
                Actuators.CallDisplayFloor2_Upward                = 0;
                Actuators.CallDisplayFloor2_Downward              = 0;
                Actuators.CallDisplayFloor3_Downward              = 0;
                Actuators.IndicatorDisplayFloor1                  = 0;
                Actuators.IndicatorDisplayFloor2                  = 0;
                Actuators.IndicatorDisplayFloor3                  = 0;
                Actuators.DrivedirectionDisplay_Downward          = 0;
                Actuators.DrivedirectionDisplay_Upward            = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor1  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor2  = 0;
                Actuators.ElevatorControl_IndicatorDisplayFloor3  = 0;
                Actuators.ElevatorControl_Alert                   = 0;
                Actuators.ElevatorControl_EmergencyStop           = 0;
                Actuators.ElevatorControl_Overload                = 0;
                Actuators.DoorFloor4_Open                         = 0;
                Actuators.DoorFloor4_Close                        = 1;
                Actuators.CallDisplayFloor3_Upwards               = 0;
                Actuators.CallDisplayFloor4                       = 0;
                Actuators.IndicatorDisplayFloor4                  = 0;
                Actuators.CallDisplayControl_ElevatorControl      = 0;
                
                if (!Sensors.Floor4_DoorClosed)
                    State = DriveToFloor1Down;
                
                break;
            }
    }
    

}