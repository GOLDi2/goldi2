#ifndef UART0_H_
#define UART0_H_

#define BAUD    250000

void UART0_Initialize();
void UART0_PutChar(char Data);

#endif // UART0_H_