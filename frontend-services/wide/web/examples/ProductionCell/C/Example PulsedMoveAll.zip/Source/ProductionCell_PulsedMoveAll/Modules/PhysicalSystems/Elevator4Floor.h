#ifndef _ELEVATOR4FLOORS_H
#define _ELEVATOR4FLOORS_H

typedef struct
{
    unsigned Elevator_on_floor_1:1;
    unsigned Elevator_on_floor_2:1;
    unsigned Elevator_on_floor_3:1;
    unsigned Elevator_above_floor_1:1;
    unsigned Elevator_below_floor_2:1;
    unsigned Elevator_above_floor_2:1;
    unsigned Elevator_below_floor_3:1;
    unsigned Floor_1_Door_open:1;
    unsigned Floor_1_Door_closed:1;
    unsigned Floor_2_Door_open:1;
    unsigned Floor_2_Door_closed:1;
    unsigned Floor_3_Door_open:1;
    unsigned Floor_3_Door_closed:1;
    unsigned Light_barrier_floor_1:1;
    unsigned Light_barrier_floor_2:1;
    unsigned Light_barrier_floor_3:1;
    unsigned Call_button_floor_1:1;
    unsigned Call_button_floor_2_up:1;
    unsigned Call_button_floor_2_down:1;
    unsigned Call_button_floor_3:1;
    unsigned Elevator_control_floor_1:1;
    unsigned Elevator_control_floor_2:1;
    unsigned Elevator_control_floor_3:1;
    unsigned Elevator_control_alert:1;
    unsigned Elevator_control_emergency_stop:1;
    unsigned Simulation_overload:1;
    unsigned Elevator_on_floor_4:1;
    unsigned Elevator_above_floor_3:1;
    unsigned Elevator_below_floor_4:1;
    unsigned Floor_4_door_open:1;
    unsigned Floor_4_door_closed:1;
    unsigned Light_barrier_floor_4:1;
    unsigned Call_button_floor_3_up:1;
    unsigned Call_button_floor_4_down:1;
    unsigned Elevator_control_floor_4:1;
    unsigned Reserve_01:1;
    unsigned Reserve_02:1;
    unsigned Reserve_03:1;
    unsigned Reserve_04:1;
    unsigned Reserve_05:1;
    unsigned char Reserve_06;
} Sensor_t;          
             
typedef struct
{
    unsigned Drive_upwards:1;
    unsigned Drive_downwards:1;
    unsigned Drive_slowly:1;
    unsigned Door_floor_1_open:1;
    unsigned Door_floor_1_close:1;
    unsigned Door_floor_2_open:1;
    unsigned Door_floor_2_close:1;
    unsigned Door_floor_3_open:1;
    unsigned Door_floor_3_close:1;
    unsigned Call_display_floor_1:1;
    unsigned Call_display_floor_2_upward:1;
    unsigned Call_display_floor_2_downward:1;
    unsigned Call_display_floor_3_downward:1;
    unsigned Indicator_display_floor_1:1;
    unsigned Indicator_display_floor_2:1;
    unsigned Indicator_display_floor_3:1;
    unsigned Drive_direction_display_downward:1;
    unsigned Drive_direction_display_upward:1;
    unsigned Elevator_control_Indicator_display_floor_1:1;
    unsigned Elevator_control_Indicator_display_floor_2:1;
    unsigned Elevator_control_Indicator_display_floor_3:1;
    unsigned Elevator_control_alert:1;
    unsigned Elevator_control_emergency_stop:1;
    unsigned Elevator_control_overload:1;
    unsigned Door_floor_4_open:1;
    unsigned Door_floor_4_close:1;
    unsigned Call_display_floor_3_upwards:1;
    unsigned Call_display_floor_4:1;
    unsigned Indicator_display_floor_4:1;
    unsigned Call_display_control_Elevator_control:1;
    unsigned Reserve_01:1;
    unsigned Reserve_02:1;
    unsigned int Reserve_03;
} Actuator_t;

#define SensorPointer (uint8_t *)&Sensors
#define ActuatorPointer (uint8_t *)&Actuators

extern Sensor_t Sensors;
extern Actuator_t Actuators;

#endif // _ELEVATOR4FLOORS_H