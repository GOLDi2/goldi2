#ifndef AUTOMAT_H_
#define AUTOMAT_H_

extern void StateMachineInit(void);		// This function init the state machine.
extern void StateMachineUpdate(void);	// This function updated the state machine.


#endif /* AUTOMAT_H_ */