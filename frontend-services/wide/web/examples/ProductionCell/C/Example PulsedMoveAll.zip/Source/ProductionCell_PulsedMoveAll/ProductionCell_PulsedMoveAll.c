#include <avr/io.h>
#include <util/delay.h>

#include "Modules/UART0.h"
#include "Modules/BusProtectionInterface.h"
#include "Design/Automaton.h"

int main(void)
{
    UART0_Initialize();
	BusProtectionInterfaceInit();
	StateMachineInit();
	
	while(1)
    {
		StateMachineUpdate();
		BusProtectionSendData();
		_delay_ms(1);
    }
}