#include "3AxisPortal.h"

Sensor_t Sensors;
Actuator_t Actuators;
