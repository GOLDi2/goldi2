#include <avr/io.h>   
#include <stdint.h>
#include <avr/interrupt.h>
#include "UART0.h"

void UART0_Initialize()
{
    UBRR0L = (F_CPU / (BAUD * 16L) - 1);
    UCSR0B = ((1<<RXEN0) | (1<<TXEN0) | (1<<RXCIE0));
    sei();
}

void UART0_PutChar(char Data)
{
    while (!(UCSR0A & (1<<UDRE0)));
    UDR0=data;
}