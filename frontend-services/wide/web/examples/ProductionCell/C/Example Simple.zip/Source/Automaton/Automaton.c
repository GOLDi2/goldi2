#include "Automaton.h"

AutomatStates_t State;
/**
This function init the state machine.
*/
void StateMachineInit(void)
{
	State= Init;
}

/**
This function updated the state machine.
*/
void StateMachineUpdate(void)
{
	/*switch (State)
	{
		case Init:
			Actuators.x_axis_to_x_plus = 0; 
			Actuators.x_axis_to_x_minus = 1;
			State = DriveDown;
			break;
		case DriveUp:
			if(!(Sensors.x_axis_at_position_x_plus))
			{
				Actuators.x_axis_to_x_plus = 0;
				Actuators.x_axis_to_x_minus = 1;
				State = DriveDown;
			}				
			break;
		case DriveDown:
			if(!(Sensors.x_axis_at_position_x_minus))
			{
				Actuators.x_axis_to_x_plus = 1;
				Actuators.x_axis_to_x_minus = 0;
				State = DriveUp;
			}
			break;
	}
	*/
	

}