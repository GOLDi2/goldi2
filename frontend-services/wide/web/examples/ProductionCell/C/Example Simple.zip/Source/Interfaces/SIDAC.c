#include "SIDAC.h"

Sensor_t Sensors;
Actuator_t Actuators;

void SIDACInit(void)
{
	
}