#include <avr/io.h>
#include <util/delay.h>

#include "UART0.h"
#include "Automaton/Automaton.h"
#include "BusProtectionInterface.h"

int main(void)
{
	UART0_init();
	BusProtectionInterfaceInit();
	
	StateMachineInit();
	
	Actuators.Conveyor_belt_1_drive_belt = 0;
	Actuators.Conveyor_belt_2_drive_belt = 0;
	Actuators.Conveyor_belt_3_drive_belt = 0;
	Actuators.Milling_head_drive_head = 0;
	Actuators.Milling_head_lower = 0;
	Actuators.Milling_head_rise = 0;
	Actuators.Milling_machine_approach_conveyor_belt_2 = 0;
	Actuators.Milling_machine_retreat_from_conveyor_belt_2 = 0;
	Actuators.Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_1 = 0;
	Actuators.Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_3 = 0;
	Actuators.Transport_table_move_to_conveyor_belt_1 = 0;
	Actuators.Transport_table_move_to_conveyor_belt_3 = 1;
	Actuators.Turntable_1_drive_belt = 0;
	Actuators.Turntable_1_rotate_to_conveyor_belt_1 = 0;
	Actuators.Turntable_1_rotate_to_conveyor_belt_2 = 0;
	Actuators.Turntable_2_drive_belt = 0;
	Actuators.Turntable_2_rotate_to_conveyor_belt_2 = 0;
	Actuators.Turntable_2_rotate_to_conveyor_belt_3 = 0;
	
	BusProtectionSendData();
	
	while(1)
    {
		//StateMachineUpdate();
		
		// Tisch holen
		while (Sensors.Transport_table_in_line_with_conveyor_belt_3_LOW_ACTIVE)
		{
			Actuators.Transport_table_move_to_conveyor_belt_3 = 1;
			BusProtectionSendData();
		}
		Actuators.Transport_table_move_to_conveyor_belt_3 = 0;
		BusProtectionSendData();
		
		// Klotz auf TT
		while (!Sensors.Transport_table_workpiece_available)
		{
			Actuators.Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_3 = 1;
			Actuators.Conveyor_belt_3_drive_belt = 1;
			BusProtectionSendData();
		}
		Actuators.Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_3 = 0;
		Actuators.Conveyor_belt_3_drive_belt = 0;
		BusProtectionSendData();
					
		// Tisch hinter
		while (Sensors.Transport_table_in_line_with_conveyor_belt_1_LOW_ACTIVE)
		{
			Actuators.Transport_table_move_to_conveyor_belt_1 = 1;
			BusProtectionSendData();
		}
		Actuators.Transport_table_move_to_conveyor_belt_1 = 0;
		BusProtectionSendData();			
					
		// Ausladen
		while (!Sensors.Conveyor_belt_1_workpiece_available)
		{
			Actuators.Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_1 = 1;
			Actuators.Conveyor_belt_1_drive_belt = 1;			
			BusProtectionSendData();
		}			
		Actuators.Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_1 = 0;
		Actuators.Conveyor_belt_1_drive_belt = 0;
		BusProtectionSendData();
					
		// Drehtisch TT1 holen
		while (Sensors.Turntable_1_in_line_with_conveyor_belt_1_LOW_ACTIVE)
		{
			Actuators.Turntable_1_rotate_to_conveyor_belt_1 = 1;
			BusProtectionSendData();
		}
		Actuators.Turntable_1_rotate_to_conveyor_belt_1 = 0;
		BusProtectionSendData();
				
		// Klotz auf TT1
		while (!Sensors.Turntable_1_workpiece_available)
		{
			Actuators.Conveyor_belt_1_drive_belt = 1;
			Actuators.Turntable_1_drive_belt = 1;
			BusProtectionSendData();
		}
		Actuators.Conveyor_belt_1_drive_belt = 0;
		Actuators.Turntable_1_drive_belt = 0;
		BusProtectionSendData();
		
		// Drehtisch TT1 holen
		while (Sensors.Turntable_1_in_line_with_conveyor_belt_2_LOW_ACTIVE)
		{
			Actuators.Turntable_1_rotate_to_conveyor_belt_2 = 1;
			BusProtectionSendData();
		}
		Actuators.Turntable_1_rotate_to_conveyor_belt_2 = 0;
		BusProtectionSendData();
		
		// Klotz auf CB2
		while (!Sensors.Conveyor_belt_2_workpiece_available)
		{
			Actuators.Conveyor_belt_2_drive_belt = 1;
			Actuators.Turntable_1_drive_belt = 1;
			BusProtectionSendData();
		}
		Actuators.Conveyor_belt_2_drive_belt = 0;
		Actuators.Turntable_1_drive_belt = 0;
		BusProtectionSendData();
			
		// Werkzeug vor
		while (Sensors.Milling_machine_at_conveyor_belt_2_LOW_ACTIVE)
		{
			Actuators.Milling_machine_approach_conveyor_belt_2 = 1;
			BusProtectionSendData();
		}
		Actuators.Milling_machine_approach_conveyor_belt_2 = 0;
		BusProtectionSendData();
			
		// Werkzeug runter
		while (Sensors.Milling_head_is_down_LOW_ACTIVE)
		{
			Actuators.Milling_head_lower = 1;
			BusProtectionSendData();
		}
		Actuators.Milling_head_lower = 0;
		BusProtectionSendData();
		
		// Werkzeug drehen
		Actuators.Milling_head_drive_head = 1;
		BusProtectionSendData();
		_delay_ms(3000);
		Actuators.Milling_head_drive_head = 0;
		BusProtectionSendData();

		// Werkzeug hoch
		while (Sensors.Milling_head_is_up_LOW_ACTIVE)
		{
			Actuators.Milling_head_rise = 1;
			BusProtectionSendData();
		}
		Actuators.Milling_head_rise = 0;
		BusProtectionSendData();
			
		// Werkzeug hinter
		while (Sensors.Milling_machine_away_from_conveyor_belt_2_LOW_ACTIVE)
		{
			Actuators.Milling_machine_retreat_from_conveyor_belt_2 = 1;
			BusProtectionSendData();
		}
		Actuators.Milling_machine_retreat_from_conveyor_belt_2 = 0;
		BusProtectionSendData();	

		// Drehtisch TT2 holen
		while (Sensors.Turntable_2_in_line_with_conveyor_belt_2_LOW_ACTIVE)
		{
			Actuators.Turntable_2_rotate_to_conveyor_belt_2 = 1;
			BusProtectionSendData();
		}
		Actuators.Turntable_2_rotate_to_conveyor_belt_2 = 0;
		BusProtectionSendData();
				
		// Klotz auf TT1
		while (!Sensors.Turntable_2_workpiece_available)
		{
			Actuators.Conveyor_belt_2_drive_belt = 1;
			Actuators.Turntable_2_drive_belt = 1;
			BusProtectionSendData();
		}
		Actuators.Conveyor_belt_2_drive_belt = 0;
		Actuators.Turntable_2_drive_belt = 0;
		BusProtectionSendData();
		
		// Drehtisch TT1 holen
		while (Sensors.Turntable_2_in_line_with_conveyor_belt_3_LOW_ACTIVE)
		{
			Actuators.Turntable_2_rotate_to_conveyor_belt_3 = 1;
			BusProtectionSendData();
		}
		Actuators.Turntable_2_rotate_to_conveyor_belt_3 = 0;
		BusProtectionSendData();
		
		// Klotz auf CB3
		while (!Sensors.Conveyor_belt_3_workpiece_available)
		{
			Actuators.Conveyor_belt_3_drive_belt = 1;
			Actuators.Turntable_2_drive_belt = 1;
			BusProtectionSendData();
		}
		Actuators.Conveyor_belt_3_drive_belt = 0;
		Actuators.Turntable_2_drive_belt = 0;
		BusProtectionSendData();			
    }
}