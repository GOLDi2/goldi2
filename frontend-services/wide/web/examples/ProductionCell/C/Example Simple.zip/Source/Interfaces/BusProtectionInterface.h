#ifndef BUSPROTECTIONINTERFACE_H_
#define BUSPROTECTIONINTERFACE_H_

#include <stdint.h>

extern void BusProtectionInterfaceInit(void);
extern void BusProtectionSendData(void);
extern void BusProtectionNewData(uint8_t Data);

extern uint8_t *BusProtectionOutputBuffer;
extern uint8_t *BusProtectionInputBuffer;

#endif /* BUSPROTECTIONINTERFACE_H_ */