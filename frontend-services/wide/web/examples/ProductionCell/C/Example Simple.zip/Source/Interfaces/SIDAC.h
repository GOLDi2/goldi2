#ifndef SIDAC_H
#define SIDAC_H

typedef struct
{
    unsigned Transport_table_move_to_conveyor_belt_3:1;                           // y 0
    unsigned Transport_table_move_to_conveyor_belt_1:1;                           // y 1
	unsigned Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_1:1;    // y 2
	unsigned Transport_table_drive_conveyor_belt_similar_to_conveyor_belt_3:1;    // y 3
	unsigned Conveyor_belt_1_drive_belt:1;                                        // y 4
	unsigned Turntable_1_rotate_to_conveyor_belt_1:1;                             // y 5
	unsigned Turntable_1_rotate_to_conveyor_belt_2:1;                             // y 6
	unsigned Turntable_1_drive_belt:1;                                            // y 7
	
	unsigned Conveyor_belt_2_drive_belt:1;                                        // y 8
	unsigned Turntable_2_rotate_to_conveyor_belt_2:1;                             // y 9
	unsigned Turntable_2_rotate_to_conveyor_belt_3:1;                             // y10
	unsigned Turntable_2_drive_belt:1;                                            // y11
    unsigned Conveyor_belt_3_drive_belt:1;                                        // y12
    unsigned Milling_machine_retreat_from_conveyor_belt_2:1;                      // y13
    unsigned Milling_machine_approach_conveyor_belt_2:1;                          // y14
    unsigned Milling_head_rise:1;                                                 // y15
	
    unsigned Milling_head_lower:1;                                                // y16
    unsigned Milling_head_drive_head:1;                                           // y17
	
	unsigned reserve0:6;
	unsigned char reserve1;	//8 bit
	unsigned int reserve2;	//16 bit
} Actuator_t;

typedef struct
{
	unsigned Transport_table_in_line_with_conveyor_belt_3_LOW_ACTIVE:1;             // x 0
	unsigned Transport_table_in_line_with_conveyor_belt_1_LOW_ACTIVE:1;             // x 1
	unsigned Transport_table_workpiece_available:1;                                 // x 2
	unsigned Conveyor_belt_1_workpiece_available:1;                                 // x 3
	unsigned Turntable_1_in_line_with_conveyor_belt_1_LOW_ACTIVE:1;                 // x 4
	unsigned Turntable_1_in_line_with_conveyor_belt_2_LOW_ACTIVE:1;                 // x 5
	unsigned Turntable_1_workpiece_available:1;                                     // x 6
	unsigned Conveyor_belt_2_workpiece_available:1;                                 // x 7
	
	unsigned Turntable_2_in_line_with_conveyor_belt_2_LOW_ACTIVE:1;                 // x 8
	unsigned Turntable_2_in_line_with_conveyor_belt_3_LOW_ACTIVE:1;                 // x 9	
	unsigned Turntable_2_workpiece_available:1;                                     // x10
	unsigned Conveyor_belt_3_workpiece_available:1;                                 // x11
	unsigned Milling_machine_away_from_conveyor_belt_2_LOW_ACTIVE:1;                // x12
	unsigned Milling_machine_at_conveyor_belt_2_LOW_ACTIVE:1;                       // x13
	unsigned Milling_head_is_up_LOW_ACTIVE:1;                                       // x14
	unsigned Milling_head_is_down_LOW_ACTIVE:1;                                     // x15
	
	unsigned Emergency_Stop:1;                                                      // x16

	unsigned reserve0:7;
	unsigned char reserve1;	//8 bit
	unsigned int reserve2;	//16 bit
} Sensor_t;

#define SensorPointer (uint8_t *)&Sensors
#define ActuatorPointer (uint8_t *)&Actuators

extern Sensor_t Sensors;
extern Actuator_t Actuators;

#endif /* SIDAC_H */