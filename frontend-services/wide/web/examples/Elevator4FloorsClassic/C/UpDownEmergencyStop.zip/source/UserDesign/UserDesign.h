// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#ifndef _USERDESIGN_H
    #define _USERDESIGN_H

    #include "../Main.h"
    extern void StateMachineInit(void);                                                     // This function initializes the state machine
    extern void StateMachineUpdate(void);                                                   // This function updated the state machine

// #########################################################################################
// #  State definitions for the Machines, notice: duplicate state identifiers NOT allowed  #
// #########################################################################################
typedef enum
{
	AutomatUpDown_DriveUp,
	AutomatUpDown_DriveDown,
	
} AutomatUpDownStates_t;
    
#endif 