// ######################################################################################
// #                                                                                    #
// #  This module implements the users design                                           #
// #                                                                                    #
// ######################################################################################

#include <util/delay.h>
#include "UserDesign.h"

AutomatUpDownStates_t A0_State;		//Machine handling the elevator cabin
AutomatUpDownStates_t A0_NextState;


// ######################################################################################
// #  This function initializes the finite state machine with start state               #
// ######################################################################################
void StateMachineInit(void)
{
    A0_State = AutomatUpDown_DriveUp;
    A0_NextState = AutomatUpDown_DriveUp;
}

// ######################################################################################
// #  This function updates the current state of the finite state machine               #
// ######################################################################################
void StateMachineUpdate(void)
{

	//Transition function delta for A0
    switch (A0_State)
     {
         case AutomatUpDown_DriveUp:
         {
             if (!Sensors.ElevatorOnFloor_4)
                A0_NextState = AutomatUpDown_DriveUp;
             else
                A0_NextState = AutomatUpDown_DriveDown;
             
             break;
         }
         
         case AutomatUpDown_DriveDown:
         {
             if (!Sensors.ElevatorOnFloor1)
				A0_NextState = AutomatUpDown_DriveDown;
             else
				A0_NextState = AutomatUpDown_DriveUp;
             break;
         }
     }


	 //Assignment of the new States to the "Flip-Flops"
	 A0_State = A0_NextState;



	 //Output functions lambda for A0
	 switch (A0_State)
	 {
		 case AutomatUpDown_DriveUp:
		 {
			//Drive the elevator upwards when not at top floor and emergency stop is depressed
			Actuators.DriveUpwards     = !Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;
			//Light up indicator when not at top floor and emergency stop is depressed 
			Actuators.DriveDirectionDisplayUpward = !Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;
			
			Actuators.DriveDirectionDisplayDownward = 0;
			Actuators.DriveDownwards   = 0;
			break;
		 }
		 
		 case AutomatUpDown_DriveDown:
		 {
			 
			 
			 //Drive the elevator downwards when not at bottom floor and emergency stop is depressed
			 Actuators.DriveDownwards   = !Sensors.ElevatorOnFloor1 && !Sensors.ElevatorControlEmergencyStop;
			 //Light up indicator when not at bottom floor and emergency stop is depressed 
			 Actuators.DriveDirectionDisplayDownward = !Sensors.ElevatorOnFloor_4 && !Sensors.ElevatorControlEmergencyStop;

			 Actuators.DriveDirectionDisplayUpward = 0;
			 Actuators.DriveUpwards     = 0;
			 break;
		 }
	 }

	 Actuators.ElevatorControlEmergencyStop = Sensors.ElevatorControlEmergencyStop;
	 

}