#!/bin/bash

zip -r firmware.zip ./